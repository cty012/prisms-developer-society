import pygame
from pygame.locals import *
import random, math


class frog(pygame.sprite.Sprite):
    def __init__(self,x_pos,y_pos,g,img):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect=self.image.get_rect()
        self.rect.x=x_pos
        self.rect.y=y_pos
        self.g=g
        self.dy=0
    def jump(self,vel):
        self.dy-=vel*1
    def update(self):
        
        
        self.dy+=1/frame*self.g
        f=self.dy*1/frame
        #print(f)
        self.rect.y+=math.ceil(self.dy*1/frame)
        #print('coord',self.rect.y)
class obstacle(pygame.sprite.Sprite):
    def __init__(self,ru,vel,img,corner,iss,qwq):
        pygame.sprite.Sprite.__init__(self)
        self.image=img
        self.rect=self.image.get_rect()
        self.dy=vel
        self.iss=iss
        if corner=="tr":
            self.rect.topright=(ru[0]+qwq,ru[1])
        elif corner=="br":
            self.rect.bottomright=(ru[0]+qwq,ru[1])
    def update(self):
        self.rect.x-=1/frame*self.dy
        if self.rect.right<=0 and self.iss:
            
            gg.text = gg.font.render(str(gg.score)+'s', True, (128, 0, 0))
            gg.destroy()

class MainGame:
    def __init__(self,width,height,title,score,vel,frame,imp,gravity):
        self.width=width
        self.height=height
        self.title=title
        self.score=score
        self.vel=vel
        self.frame=frame
        self.imp=imp
        self.gravity=gravity
        pygame.init()
        self.screen=pygame.display.set_mode((self.width,self.height))
        pygame.display.set_caption(self.title)
        pygame.mixer.init()
        self.sprite_list=None
        self.obs_list=None
        self.angry=False
    def setup(self):
        self.score=0
        self.sprite_list=pygame.sprite.Group()
        self.background = pygame.Surface(self.screen.get_size())
        self.background = self.background.convert()
        self.background.fill((50, 250, 50))
        self.jzm=frog(50,200,self.gravity,him)
        self.sprite_list.add(self.jzm)
        self.obs_list=pygame.sprite.Group()
        self.finish()
        #self.sou=pygame.mixer.Sound("xxx.ogg")
        #self.sou.set_volume(.2)
        #self.sou.play()
        self.cool=0
        cool_frame=frame/6
        self.font = pygame.font.SysFont("comicsansms", 72)
        self.text = self.font.render(str(self.score)+'s', True, (128, 0, 0))
        self.clock = pygame.time.Clock()
        self.angry=False
    def sound(self):
        pass
        #pygame.mixer.music.load(str(random.randint(1,43))+".mp3")
        #pygame.mixer.music.play()
    def destroy(self):
        for spr in self.obs_list:
            spr.kill()
        self.finish()
        self.score+=1
        self.text = self.font.render(str(self.score)+'s', True, (128, 0, 0))
    def finish(self):
        for spr in self.generate(random.choice(qaq)):
            self.sprite_list.add(spr)
            self.obs_list.add(spr)
    def generate(self,rep):
        le=600-gap
        size=yzb.get_size()[0]
        scale=le/height
        h1=random.randint(50,400)
        yz=pygame.transform.scale(yzb,(int(size*scale),le))
        siez=yz.get_size()[1]
        upper=yz.subsurface((0,0,yz.get_size()[0],h1))
        lower=yz.subsurface(pygame.Rect(0,h1,yz.get_size()[0],siez-h1))
        return [obstacle((self.width,self.height),self.vel,lower,"br",False,60*i) for i in range(0,rep-1)]+[obstacle((self.width,0),self.vel,upper,"tr",False,j*60) for j in range(0,rep-1)]+[obstacle((self.width,self.height),self.vel,lower,"br",True,60*rep-60)]+[obstacle((self.width,0),self.vel,upper,"tr",True,rep*60-60)]
    #def angryy(self):
        #ang=pygame.transform.scale(him,(160,200))
        #self.jzm.image=ang
        #self.jzm.rect=self.jzm.image.get_rect()
    def update(self):
        #print(cool)
        self.cool=max(self.cool-1,0)
        #print(clock.get_rawtime())
        #print(pygame.event.get())
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.display.quit()
                quit()
            if event.type == MOUSEBUTTONDOWN:
                if self.cool==0:
                    self.sound()
                    self.jzm.jump(self.imp)
                    self.cool=cool_frame
            if event.type == pygame.KEYDOWN and event.key == pygame.K_a:
                self.angry=True
                #self.angryy()
        if self.angry:
            pygame.sprite.spritecollide(self.jzm,self.obs_list,True)
        else:
            if pygame.sprite.spritecollide(self.jzm,self.obs_list,False):
                return False
        if self.jzm.rect.bottom>=height or self.jzm.rect.top<=0:
            return False
        self.sprite_list.update()

        self.screen.blit(self.background,(0,0))
        
        self.sprite_list.draw(self.screen)
        #self.screen.blit(self.text,
        #(100,100))
        #print(score)
        pygame.display.flip()
        return True
if True:
    width=400
    height=600
    frame=80
    gap=150
    cool_frame=5
    title="Just Say"
    him=pygame.image.load("imgs/zz2.jpg")
    yzb=pygame.image.load("imgs/yazuibi2.jpg")
    him=pygame.transform.scale(him,(40,50))
    qaq=[1,1,1,1,1,2,2,2,2,1,3,3,4,5,4,5,6,7]
    gg=MainGame(width,height,title,0,250,60,500,1200)
    gg.setup()
    
    going=True
    while True:
        
        while gg.update():
            
            gg.clock.tick(gg.frame)
        
        gg.setup()
