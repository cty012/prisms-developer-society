import main.app as app
import utils.args as a


args = a.Args(scale=1)
app.launch(args)
