class Controls:
    def __init__(self, map):
        self.map = map
        self.cursor = None
